-- ============================================================
-- PROJECT  : HR Analytics — End to End
-- FILE     : 03_hr_queries.sql
-- DATABASE : Oracle 10g+
-- AUTHOR   : Your Name
-- DATE     : 2024
-- DESC     : 10 HR Analytics queries
-- ============================================================

SET LINESIZE 200
SET PAGESIZE 50
SET SERVEROUTPUT ON

-- ─────────────────────────────────────────
-- Q1: ATTRITION RATE BY DEPARTMENT
-- ─────────────────────────────────────────
SELECT
    d.dept_name,
    COUNT(e.emp_id)                                          AS total_employees,
    SUM(CASE WHEN e.attrition = 'Yes' THEN 1 ELSE 0 END)    AS attrition_count,
    ROUND(SUM(CASE WHEN e.attrition = 'Yes' THEN 1 ELSE 0 END) * 100 / COUNT(e.emp_id), 2) AS attrition_rate_pct
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY d.dept_name
ORDER BY attrition_rate_pct DESC;

-- ─────────────────────────────────────────
-- Q2: AVERAGE SALARY BY JOB ROLE
-- ─────────────────────────────────────────
SELECT
    job_role,
    COUNT(emp_id)               AS headcount,
    ROUND(AVG(salary), 2)       AS avg_salary,
    MIN(salary)                 AS min_salary,
    MAX(salary)                 AS max_salary
FROM employees
GROUP BY job_role
ORDER BY avg_salary DESC;

-- ─────────────────────────────────────────
-- Q3: TOP 10 PERFORMERS
-- ─────────────────────────────────────────
SELECT *
FROM (
    SELECT
        e.emp_id,
        e.full_name,
        d.dept_name,
        e.job_role,
        e.salary,
        r.performance_score,
        r.rating_label,
        r.promotion,
        RANK() OVER (ORDER BY r.performance_score DESC) AS perf_rank
    FROM employees e
    JOIN departments d         ON e.dept_id  = d.dept_id
    JOIN performance_reviews r ON e.emp_id   = r.emp_id
    WHERE r.review_year = 2024
)
WHERE perf_rank <= 10;

-- ─────────────────────────────────────────
-- Q4: SALARY BAND DISTRIBUTION
-- ─────────────────────────────────────────
SELECT
    CASE
        WHEN salary < 40000  THEN 'Below 40K'
        WHEN salary < 60000  THEN '40K - 60K'
        WHEN salary < 80000  THEN '60K - 80K'
        WHEN salary < 100000 THEN '80K - 1L'
        ELSE 'Above 1L'
    END                         AS salary_band,
    COUNT(emp_id)               AS employee_count,
    ROUND(AVG(salary), 0)       AS avg_salary
FROM employees
GROUP BY
    CASE
        WHEN salary < 40000  THEN 'Below 40K'
        WHEN salary < 60000  THEN '40K - 60K'
        WHEN salary < 80000  THEN '60K - 80K'
        WHEN salary < 100000 THEN '80K - 1L'
        ELSE 'Above 1L'
    END
ORDER BY avg_salary;

-- ─────────────────────────────────────────
-- Q5: TENURE ANALYSIS (EXPERIENCE GROUPS)
-- ─────────────────────────────────────────
SELECT
    CASE
        WHEN experience_years < 2   THEN '0-2 Years'
        WHEN experience_years < 5   THEN '2-5 Years'
        WHEN experience_years < 10  THEN '5-10 Years'
        WHEN experience_years < 20  THEN '10-20 Years'
        ELSE '20+ Years'
    END                                                     AS tenure_group,
    COUNT(emp_id)                                           AS headcount,
    ROUND(AVG(salary), 0)                                   AS avg_salary,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END)     AS attrition_count
FROM employees
GROUP BY
    CASE
        WHEN experience_years < 2   THEN '0-2 Years'
        WHEN experience_years < 5   THEN '2-5 Years'
        WHEN experience_years < 10  THEN '5-10 Years'
        WHEN experience_years < 20  THEN '10-20 Years'
        ELSE '20+ Years'
    END
ORDER BY avg_salary;

-- ─────────────────────────────────────────
-- Q6: GENDER DIVERSITY BY DEPARTMENT
-- ─────────────────────────────────────────
SELECT
    d.dept_name,
    SUM(CASE WHEN e.gender = 'Male'   THEN 1 ELSE 0 END)   AS male_count,
    SUM(CASE WHEN e.gender = 'Female' THEN 1 ELSE 0 END)   AS female_count,
    COUNT(e.emp_id)                                         AS total,
    ROUND(SUM(CASE WHEN e.gender = 'Female' THEN 1 ELSE 0 END) * 100 / COUNT(e.emp_id), 1) AS female_pct
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY d.dept_name
ORDER BY female_pct DESC;

-- ─────────────────────────────────────────
-- Q7: HIGH ATTRITION RISK EMPLOYEES
-- ─────────────────────────────────────────
SELECT
    e.emp_id,
    e.full_name,
    d.dept_name,
    e.job_role,
    e.salary,
    e.experience_years,
    r.performance_score,
    r.rating_label,
    'HIGH RISK' AS risk_level
FROM employees e
JOIN departments d         ON e.dept_id  = d.dept_id
JOIN performance_reviews r ON e.emp_id   = r.emp_id
WHERE r.performance_score < 3.0
  AND e.attrition = 'No'
  AND e.experience_years < 5
ORDER BY r.performance_score ASC;

-- ─────────────────────────────────────────
-- Q8: DEPARTMENT SALARY vs BUDGET
-- ─────────────────────────────────────────
SELECT
    d.dept_name,
    d.budget                        AS dept_budget,
    SUM(e.salary * 12)              AS annual_salary_cost,
    d.budget - SUM(e.salary * 12)   AS remaining_budget,
    ROUND(SUM(e.salary * 12) * 100 / d.budget, 1) AS budget_utilization_pct
FROM departments d
JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name, d.budget
ORDER BY budget_utilization_pct DESC;

-- ─────────────────────────────────────────
-- Q9: EDUCATION LEVEL VS AVG SALARY
-- ─────────────────────────────────────────
SELECT
    education,
    COUNT(emp_id)           AS headcount,
    ROUND(AVG(salary), 0)   AS avg_salary,
    MIN(salary)             AS min_salary,
    MAX(salary)             AS max_salary,
    ROUND(AVG(experience_years), 1) AS avg_experience
FROM employees
GROUP BY education
ORDER BY avg_salary DESC;

-- ─────────────────────────────────────────
-- Q10: FULL HR REPORT — ALL DETAILS
-- ─────────────────────────────────────────
SELECT
    e.emp_id,
    e.full_name,
    e.gender,
    e.age,
    d.dept_name,
    e.job_role,
    e.salary,
    e.experience_years,
    e.education,
    e.attrition,
    r.performance_score,
    r.rating_label,
    r.promotion,
    r.training_hours,
    e.city
FROM employees e
JOIN departments d         ON e.dept_id  = d.dept_id
JOIN performance_reviews r ON e.emp_id   = r.emp_id
WHERE r.review_year = 2024
ORDER BY d.dept_name, r.performance_score DESC;

-- ============================================================
-- END OF 03_hr_queries.sql
-- ============================================================
