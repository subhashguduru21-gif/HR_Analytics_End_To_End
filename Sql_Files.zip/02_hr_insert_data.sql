-- ============================================================
-- PROJECT  : HR Analytics — End to End
-- FILE     : 02_hr_insert_data.sql
-- DATABASE : Oracle 10g+
-- AUTHOR   : Your Name
-- DATE     : 2024
-- DESC     : Insert departments + 50 sample employees
-- ============================================================

SET SERVEROUTPUT ON
SET FEEDBACK OFF

-- ─────────────────────────────────────────
-- TABLE 1: DEPARTMENTS (8 rows)
-- ─────────────────────────────────────────
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Engineering',       'Hyderabad',  'Rajesh Kumar',    8500000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Sales',             'Mumbai',     'Priya Sharma',    6000000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Human Resources',   'Bangalore',  'Anita Nair',      3000000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Finance',           'Delhi',      'Suresh Menon',    4500000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Marketing',         'Pune',       'Deepa Reddy',     4000000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Operations',        'Chennai',    'Vikram Patel',    5000000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Customer Support',  'Kolkata',    'Meena Pillai',    2500000);
INSERT INTO departments VALUES (seq_dept_id.NEXTVAL, 'Research',          'Hyderabad',  'Arun Krishnan',   7000000);

COMMIT;

-- ─────────────────────────────────────────
-- TABLE 2: EMPLOYEES (50 rows)
-- ─────────────────────────────────────────
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Arjun Sharma',    'arjun.sharma@company.com',    '9876543210','Male',  28,1,'Software Engineer',  65000,4, TO_DATE('2020-03-15','YYYY-MM-DD'),'No', 'Single',  'Graduate',      'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Priya Nair',      'priya.nair@company.com',      '9845123456','Female',32,2,'Sales Executive',     45000,7, TO_DATE('2017-06-01','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Ravi Kumar',      'ravi.kumar@company.com',      '9731234567','Male',  45,4,'Finance Manager',     95000,20,TO_DATE('2004-01-10','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Delhi');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Sneha Reddy',     'sneha.reddy@company.com',     '9654321098','Female',26,5,'Marketing Analyst',   42000,3, TO_DATE('2021-08-20','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Amit Das',        'amit.das@company.com',        '9123456789','Male',  35,1,'Senior Developer',    85000,10,TO_DATE('2014-05-12','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Pooja Ghosh',     'pooja.ghosh@company.com',     '9876012345','Female',29,3,'HR Executive',        38000,5, TO_DATE('2019-11-03','YYYY-MM-DD'),'No', 'Single',  'Graduate',      'Bangalore');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Vikram Mehta',    'vikram.mehta@company.com',    '9988776655','Male',  42,6,'Operations Manager',  88000,17,TO_DATE('2007-02-28','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Chennai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Anita Joshi',     'anita.joshi@company.com',     '9871234560','Female',31,2,'Sales Manager',       72000,8, TO_DATE('2016-09-15','YYYY-MM-DD'),'Yes','Married', 'Post Graduate', 'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Suresh Babu',     'suresh.babu@company.com',     '9765432109','Male',  38,8,'Research Scientist',  92000,13,TO_DATE('2011-04-20','YYYY-MM-DD'),'No', 'Married', 'PhD',           'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Kavitha Rajan',   'kavitha.rajan@company.com',   '9654098765','Female',24,7,'Support Executive',   32000,2, TO_DATE('2022-01-10','YYYY-MM-DD'),'Yes','Single',  'High School',   'Kolkata');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Rohit Verma',     'rohit.verma@company.com',     '9543210987','Male',  33,1,'DevOps Engineer',     78000,8, TO_DATE('2016-07-05','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Meena Pillai',    'meena.pillai@company.com',    '9432109876','Female',47,3,'HR Manager',          82000,22,TO_DATE('2002-03-18','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Bangalore');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Kiran Patil',     'kiran.patil@company.com',     '9321098765','Male',  27,5,'Digital Marketer',    44000,4, TO_DATE('2020-10-25','YYYY-MM-DD'),'No', 'Single',  'Graduate',      'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Deepa Iyer',      'deepa.iyer@company.com',      '9210987654','Female',36,4,'Financial Analyst',   68000,11,TO_DATE('2013-06-30','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Delhi');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Arun Krishnan',   'arun.krishnan@company.com',   '9109876543','Male',  50,8,'Research Director',  120000,25,TO_DATE('1999-08-14','YYYY-MM-DD'),'No', 'Married', 'PhD',           'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Sunita Singh',    'sunita.singh@company.com',    '9098765432','Female',30,2,'Sales Executive',     43000,6, TO_DATE('2018-12-01','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Manoj Tiwari',    'manoj.tiwari@company.com',    '8987654321','Male',  40,6,'Operations Lead',     76000,15,TO_DATE('2009-05-22','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Chennai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Rekha Gupta',     'rekha.gupta@company.com',     '8876543210','Female',25,5,'Content Writer',      35000,2, TO_DATE('2022-03-08','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Sanjay Rao',      'sanjay.rao@company.com',      '8765432109','Male',  44,4,'Finance Director',   115000,19,TO_DATE('2005-11-15','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Delhi');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Lakshmi Devi',    'lakshmi.devi@company.com',    '8654321098','Female',28,7,'Support Analyst',     34000,4, TO_DATE('2020-07-19','YYYY-MM-DD'),'No', 'Married', 'High School',   'Kolkata');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Ganesh Patel',    'ganesh.patel@company.com',    '8543210987','Male',  37,1,'Tech Lead',           95000,12,TO_DATE('2012-09-03','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Usha Menon',      'usha.menon@company.com',      '8432109876','Female',52,3,'HR Director',        105000,27,TO_DATE('1997-04-11','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Bangalore');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Bala Subramanian','bala.subramanian@company.com','8321098765','Male',  23,2,'Sales Trainee',       28000,1, TO_DATE('2023-06-01','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Nisha Kapoor',    'nisha.kapoor@company.com',    '8210987654','Female',34,5,'Brand Manager',       74000,9, TO_DATE('2015-02-14','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Rahul Bose',      'rahul.bose@company.com',      '8109876543','Male',  29,1,'Python Developer',    72000,5, TO_DATE('2019-08-26','YYYY-MM-DD'),'No', 'Single',  'Graduate',      'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Divya Nambiar',   'divya.nambiar@company.com',   '7998765432','Female',26,8,'Junior Researcher',   48000,3, TO_DATE('2021-10-05','YYYY-MM-DD'),'No', 'Single',  'Post Graduate', 'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Ajay Mishra',     'ajay.mishra@company.com',     '7887654321','Male',  41,6,'Supply Chain Lead',   80000,16,TO_DATE('2008-03-20','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Chennai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Saranya Kumar',   'saranya.kumar@company.com',   '7776543210','Female',27,5,'SEO Specialist',      40000,4, TO_DATE('2020-12-15','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Nitin Desai',     'nitin.desai@company.com',     '7665432109','Male',  36,4,'Tax Consultant',      70000,11,TO_DATE('2013-01-08','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Delhi');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Asha Pillai',     'asha.pillai@company.com',     '7554321098','Female',30,7,'Customer Success',    36000,6, TO_DATE('2018-05-22','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Kolkata');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Vinod Sharma',    'vinod.sharma@company.com',    '7443210987','Male',  48,6,'Operations Director',108000,23,TO_DATE('2001-07-16','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Chennai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Padma Venkat',    'padma.venkat@company.com',    '7332109876','Female',33,2,'Key Account Mgr',    65000,9, TO_DATE('2015-11-30','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Harish Nair',     'harish.nair@company.com',     '7221098765','Male',  22,1,'Junior Developer',    42000,1, TO_DATE('2023-08-01','YYYY-MM-DD'),'No', 'Single',  'Graduate',      'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Geeta Jain',      'geeta.jain@company.com',      '7110987654','Female',39,3,'Talent Acquisition',  55000,14,TO_DATE('2010-09-12','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Bangalore');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Prasad Kulkarni', 'prasad.kulkarni@company.com', '7009876543','Male',  31,8,'Data Scientist',      88000,7, TO_DATE('2017-03-25','YYYY-MM-DD'),'No', 'Married', 'PhD',           'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Radha Krishnan',  'radha.krishnan@company.com',  '6998765432','Female',43,3,'HR Business Partner', 68000,18,TO_DATE('2006-06-08','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Bangalore');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Sunil Rawat',     'sunil.rawat@company.com',     '6887654321','Male',  25,2,'Inside Sales Rep',    33000,2, TO_DATE('2022-09-14','YYYY-MM-DD'),'Yes','Single',  'High School',   'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Bindhu Thomas',   'bindhu.thomas@company.com',   '6776543210','Female',35,5,'Campaign Manager',    62000,10,TO_DATE('2014-04-17','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Prakash Raj',     'prakash.raj@company.com',     '6665432109','Male',  46,4,'CFO',                145000,21,TO_DATE('2003-10-05','YYYY-MM-DD'),'No', 'Married', 'PhD',           'Delhi');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Swathi Reddy',    'swathi.reddy@company.com',    '6554321098','Female',24,7,'Support Executive',   31000,1, TO_DATE('2023-02-20','YYYY-MM-DD'),'Yes','Single',  'High School',   'Kolkata');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Mohan Lal',       'mohan.lal@company.com',       '6443210987','Male',  55,6,'Senior Ops Manager',  98000,30,TO_DATE('1994-08-30','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Chennai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Chitra Devi',     'chitra.devi@company.com',     '6332109876','Female',28,8,'Research Analyst',    52000,4, TO_DATE('2020-06-11','YYYY-MM-DD'),'No', 'Single',  'Post Graduate', 'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Ramesh Babu',     'ramesh.babu@company.com',     '6221098765','Male',  32,1,'QA Engineer',         58000,7, TO_DATE('2017-11-22','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Jyothi Menon',    'jyothi.menon@company.com',    '6110987654','Female',37,5,'Product Marketer',    66000,12,TO_DATE('2012-07-04','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Pune');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Venkat Raman',    'venkat.raman@company.com',    '6009876543','Male',  29,2,'Business Dev Exec',   47000,5, TO_DATE('2019-04-16','YYYY-MM-DD'),'Yes','Single',  'Graduate',      'Mumbai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Anand Raj',       'anand.raj@company.com',       '5998765432','Male',  34,1,'Cloud Architect',     105000,9,TO_DATE('2015-08-09','YYYY-MM-DD'),'No', 'Married', 'Post Graduate', 'Hyderabad');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Suma Prakash',    'suma.prakash@company.com',    '5887654321','Female',26,3,'Recruiter',            36000,3,TO_DATE('2021-05-18','YYYY-MM-DD'),'No', 'Single',  'Graduate',      'Bangalore');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Dinesh Kumar',    'dinesh.kumar@company.com',    '5776543210','Male',  43,6,'Logistics Manager',   77000,18,TO_DATE('2006-12-27','YYYY-MM-DD'),'No', 'Married', 'Graduate',      'Chennai');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Kavya Nair',      'kavya.nair@company.com',      '5665432109','Female',23,7,'Chat Support',         29000,1,TO_DATE('2023-10-02','YYYY-MM-DD'),'Yes','Single',  'High School',   'Kolkata');
INSERT INTO employees VALUES (seq_emp_id.NEXTVAL,'Ashok Pandey',    'ashok.pandey@company.com',    '5554321098','Male',  39,8,'Senior Scientist',     96000,14,TO_DATE('2010-02-15','YYYY-MM-DD'),'No', 'Married', 'PhD',           'Hyderabad');

COMMIT;

-- ─────────────────────────────────────────
-- TABLE 3: PERFORMANCE REVIEWS (50 rows)
-- ─────────────────────────────────────────
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1001,2024,4.2,'Good',      'No', 24,'Consistently meets targets');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1002,2024,3.5,'Average',   'No', 18,'Needs improvement in client handling');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1003,2024,4.8,'Excellent', 'Yes',10,'Exceptional financial leadership');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1004,2024,2.8,'Poor',      'No', 30,'Performance declining — exit risk');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1005,2024,4.5,'Excellent', 'Yes',20,'Strong technical delivery');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1006,2024,3.8,'Good',      'No', 15,'Good team coordination');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1007,2024,4.6,'Excellent', 'Yes',12,'Operational excellence achieved');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1008,2024,3.2,'Average',   'No', 22,'Sales targets partially met');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1009,2024,5.0,'Outstanding','Yes',8,'Breakthrough research publication');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1010,2024,2.5,'Poor',      'No', 35,'Frequent absences noted');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1011,2024,4.1,'Good',      'No', 18,'Reliable DevOps delivery');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1012,2024,4.7,'Excellent', 'Yes',10,'Strategic HR leadership');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1013,2024,3.6,'Good',      'No', 20,'Digital campaigns showing results');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1014,2024,4.3,'Good',      'No', 14,'Accurate financial reporting');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1015,2024,5.0,'Outstanding','Yes',6, 'Research excellence — patent filed');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1016,2024,2.9,'Poor',      'No', 28,'Low sales conversion rate');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1017,2024,4.4,'Good',      'No', 16,'Smooth supply chain operations');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1018,2024,2.7,'Poor',      'No', 32,'Content quality needs work');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1019,2024,4.9,'Outstanding','Yes',8, 'Finance strategy impact high');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1020,2024,3.4,'Average',   'No', 20,'Support quality average');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1021,2024,4.5,'Excellent', 'Yes',15,'Tech lead driving innovation');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1022,2024,4.8,'Excellent', 'Yes',10,'HR director impact high');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1023,2024,2.4,'Poor',      'No', 38,'Sales trainee — not meeting targets');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1024,2024,4.2,'Good',      'No', 18,'Brand campaigns effective');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1025,2024,3.9,'Good',      'No', 22,'Python projects delivered well');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1026,2024,4.0,'Good',      'No', 16,'Good research contributions');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1027,2024,4.3,'Good',      'No', 14,'Supply chain optimized');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1028,2024,2.6,'Poor',      'No', 30,'SEO targets not achieved');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1029,2024,4.1,'Good',      'No', 18,'Tax advisory well received');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1030,2024,2.8,'Poor',      'No', 26,'Customer complaints high');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1031,2024,4.7,'Excellent', 'Yes',10,'Operations turnaround success');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1032,2024,4.0,'Good',      'No', 20,'Key accounts retained');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1033,2024,3.5,'Average',   'No', 25,'Junior dev learning curve');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1034,2024,4.4,'Good',      'No', 14,'Talent pipeline improved');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1035,2024,4.8,'Excellent', 'Yes',8, 'ML models in production');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1036,2024,4.2,'Good',      'No', 16,'HR strategy well executed');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1037,2024,2.5,'Poor',      'No', 32,'Inside sales below quota');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1038,2024,4.0,'Good',      'No', 18,'Campaign ROI improved');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1039,2024,5.0,'Outstanding','Yes',6, 'CFO driving P&L excellently');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1040,2024,2.3,'Poor',      'No', 40,'Support exec — poor attendance');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1041,2024,4.5,'Excellent', 'No', 12,'Senior ops expertise valued');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1042,2024,3.8,'Good',      'No', 20,'Research analysis solid');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1043,2024,4.0,'Good',      'No', 18,'QA coverage improved');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1044,2024,4.3,'Good',      'No', 16,'Product marketing impactful');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1045,2024,2.7,'Poor',      'No', 30,'Biz dev targets missed');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1046,2024,4.6,'Excellent', 'Yes',10,'Cloud architecture praised');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1047,2024,3.7,'Good',      'No', 20,'Recruitment targets met');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1048,2024,4.2,'Good',      'No', 14,'Logistics streamlined');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1049,2024,2.2,'Poor',      'No', 42,'Chat support quality low');
INSERT INTO performance_reviews VALUES (seq_review_id.NEXTVAL,1050,2024,4.9,'Outstanding','Yes',8, 'Breakthrough research output');

COMMIT;

-- ─────────────────────────────────────────
-- VERIFY
-- ─────────────────────────────────────────
SELECT 'DEPARTMENTS'       AS tbl, COUNT(*) AS rows FROM departments      UNION ALL
SELECT 'EMPLOYEES'         AS tbl, COUNT(*) AS rows FROM employees         UNION ALL
SELECT 'PERFORMANCE_REVIEWS' AS tbl, COUNT(*) AS rows FROM performance_reviews;

-- ============================================================
-- END OF 02_hr_insert_data.sql
-- ============================================================
