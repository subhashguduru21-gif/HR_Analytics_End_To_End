-- ============================================================
-- PROJECT  : HR Analytics — End to End
-- FILE     : 01_hr_schema.sql
-- DATABASE : Oracle 10g+
-- AUTHOR   : Your Name
-- DATE     : 2024
-- DESC     : HR Database — 3 tables with constraints and sequences
-- ============================================================

SET SERVEROUTPUT ON

-- ─────────────────────────────────────────
-- STEP 1: DROP TABLES
-- ─────────────────────────────────────────
BEGIN EXECUTE IMMEDIATE 'DROP TABLE performance_reviews CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE employees CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE departments CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- ─────────────────────────────────────────
-- STEP 2: DROP SEQUENCES
-- ─────────────────────────────────────────
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_dept_id';   EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_emp_id';    EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_review_id'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- ─────────────────────────────────────────
-- STEP 3: CREATE SEQUENCES
-- ─────────────────────────────────────────
CREATE SEQUENCE seq_dept_id   START WITH 1    INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_emp_id    START WITH 1001 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_review_id START WITH 1    INCREMENT BY 1 NOCACHE NOCYCLE;

-- ─────────────────────────────────────────
-- TABLE 1: DEPARTMENTS
-- ─────────────────────────────────────────
CREATE TABLE departments (
    dept_id       NUMBER          PRIMARY KEY,
    dept_name     VARCHAR2(50)    NOT NULL UNIQUE,
    location      VARCHAR2(50),
    manager_name  VARCHAR2(100),
    budget        NUMBER(12,2)
);

COMMENT ON TABLE  departments           IS 'HR department master data';
COMMENT ON COLUMN departments.dept_id   IS 'Primary key from seq_dept_id';

-- ─────────────────────────────────────────
-- TABLE 2: EMPLOYEES
-- ─────────────────────────────────────────
CREATE TABLE employees (
    emp_id            NUMBER          PRIMARY KEY,
    full_name         VARCHAR2(100)   NOT NULL,
    email             VARCHAR2(150)   NOT NULL UNIQUE,
    phone             VARCHAR2(15),
    gender            VARCHAR2(10),
    age               NUMBER,
    dept_id           NUMBER          NOT NULL,
    job_role          VARCHAR2(50)    NOT NULL,
    salary            NUMBER(10,2)    NOT NULL,
    experience_years  NUMBER,
    hire_date         DATE            NOT NULL,
    attrition         VARCHAR2(5)     DEFAULT 'No',
    marital_status    VARCHAR2(15),
    education         VARCHAR2(30),
    city              VARCHAR2(50),
    CONSTRAINT fk_emp_dept     FOREIGN KEY (dept_id) REFERENCES departments(dept_id),
    CONSTRAINT chk_gender      CHECK (gender IN ('Male','Female','Other')),
    CONSTRAINT chk_attrition   CHECK (attrition IN ('Yes','No')),
    CONSTRAINT chk_age         CHECK (age BETWEEN 18 AND 65),
    CONSTRAINT chk_salary      CHECK (salary > 0),
    CONSTRAINT chk_education   CHECK (education IN ('High School','Graduate','Post Graduate','PhD')),
    CONSTRAINT chk_marital     CHECK (marital_status IN ('Single','Married','Divorced'))
);

COMMENT ON TABLE  employees             IS '1000 employee records with HR attributes';
COMMENT ON COLUMN employees.attrition   IS 'Yes = employee left, No = still working';

-- ─────────────────────────────────────────
-- TABLE 3: PERFORMANCE REVIEWS
-- ─────────────────────────────────────────
CREATE TABLE performance_reviews (
    review_id         NUMBER          PRIMARY KEY,
    emp_id            NUMBER          NOT NULL,
    review_year       NUMBER(4)       NOT NULL,
    performance_score NUMBER(3,1)     NOT NULL,
    rating_label      VARCHAR2(20),
    promotion         VARCHAR2(5)     DEFAULT 'No',
    training_hours    NUMBER,
    manager_feedback  VARCHAR2(200),
    CONSTRAINT fk_review_emp      FOREIGN KEY (emp_id) REFERENCES employees(emp_id),
    CONSTRAINT chk_perf_score     CHECK (performance_score BETWEEN 1 AND 5),
    CONSTRAINT chk_promotion      CHECK (promotion IN ('Yes','No')),
    CONSTRAINT chk_review_year    CHECK (review_year BETWEEN 2018 AND 2024)
);

COMMENT ON TABLE  performance_reviews               IS 'Annual performance review per employee';
COMMENT ON COLUMN performance_reviews.rating_label  IS 'Poor, Average, Good, Excellent, Outstanding';

-- ─────────────────────────────────────────
-- STEP 4: INDEXES
-- ─────────────────────────────────────────
CREATE INDEX idx_emp_dept       ON employees(dept_id);
CREATE INDEX idx_emp_attrition  ON employees(attrition);
CREATE INDEX idx_emp_role       ON employees(job_role);
CREATE INDEX idx_emp_salary     ON employees(salary);
CREATE INDEX idx_review_emp     ON performance_reviews(emp_id);
CREATE INDEX idx_review_year    ON performance_reviews(review_year);

-- ─────────────────────────────────────────
-- VERIFY
-- ─────────────────────────────────────────
SELECT table_name FROM user_tables
WHERE table_name IN ('DEPARTMENTS','EMPLOYEES','PERFORMANCE_REVIEWS')
ORDER BY table_name;

-- ============================================================
-- END OF 01_hr_schema.sql
-- ============================================================
